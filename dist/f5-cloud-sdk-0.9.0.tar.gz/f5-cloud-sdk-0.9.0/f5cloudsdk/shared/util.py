""" Helper utility functions """

def multiply(n_1, n_2):
    """ Multiply two numbers """
    return n_1 * n_2
